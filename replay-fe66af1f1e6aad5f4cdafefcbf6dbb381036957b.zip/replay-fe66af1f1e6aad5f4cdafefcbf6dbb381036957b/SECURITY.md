# Security Policy

The @puppeteer/replay project takes security very seriously. Please use Chromium's process to report security issues.

## Reporting a Vulnerability

See https://www.chromium.org/Home/chromium-security/reporting-security-bugs/
