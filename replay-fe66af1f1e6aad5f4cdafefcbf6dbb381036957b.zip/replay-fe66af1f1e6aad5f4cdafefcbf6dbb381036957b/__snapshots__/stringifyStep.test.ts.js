exports['stringifyStep should stringify a single step 1'] = `
{
  const targetPage = page;
  await targetPage.goto('https://localhost/');
}

`;
