[@puppeteer/replay](../README.md) / [Schema](../modules/Schema.md) / AssertedEventType

# Enumeration: AssertedEventType

[Schema](../modules/Schema.md).AssertedEventType

## Table of contents

### Enumeration Members

- [Navigation](Schema.AssertedEventType.md#navigation)

## Enumeration Members

### Navigation

• **Navigation** = `"navigation"`

#### Defined in

[Schema.ts:50](https://github.com/puppeteer/replay/blob/main/src/Schema.ts#L50)
